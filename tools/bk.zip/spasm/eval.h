#ifndef _SPASM_EVAL_H
#define _SPASM_EVAL_H

unsigned int spasm_eval(char *expr);

#endif
